import FinancialFuture from './FinancialFuture';

export default function Page() {
  return <FinancialFuture />;
}