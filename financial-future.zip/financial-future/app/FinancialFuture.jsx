import React, { useState } from 'react';

export default function FinancialFuture() {
  const [msg, setMsg] = useState('Hola, bienvenido a Financial Future');
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">{msg}</h1>
      <button onClick={() => setMsg('Chat IA simulado')} className="px-4 py-2 bg-green-600 text-white rounded">
        Abrir Chat
      </button>
    </div>
  );
}